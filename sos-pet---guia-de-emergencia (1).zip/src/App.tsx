/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  Clock, 
  Sparkles, 
  CheckCircle, 
  Flame, 
  HelpCircle, 
  ChevronRight, 
  Lock, 
  Gift, 
  ShieldCheck, 
  TrendingUp, 
  ArrowRight,
  Heart,
  Skull,
  Award,
  BookOpen,
  Phone,
  AlertCircle
} from 'lucide-react';

// Subcomponents
import BookMockup from './components/BookMockup';
import CrisisSimulator from './components/CrisisSimulator';
import ModuleAccordion from './components/ModuleAccordion';
import FAQSection from './components/FAQSection';
import Testimonials from './components/Testimonials';
import CheckoutModal from './components/CheckoutModal';

export default function App() {
  // Modal State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  // Real-time dynamic timer for FOMO (starts from 14m 59s)
  const [time, setTime] = useState(899); // 15 minutes in seconds
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTime((prev) => (prev > 0 ? prev - 1 : 899));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const PROMO_PRICE = 9.97;

  const handlePurchase = () => {
    window.location.href = "https://pay.cakto.com.br/3bcdr6e_899309";
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 selection:bg-red-600 selection:text-white" id="main-view">
      
      {/* 1. STICKY TOP TICKER URGENCY BANNER */}
      <div className="bg-black text-white font-mono text-[11px] sm:text-xs text-center py-2px-4 shadow sticky top-0 z-40 flex flex-wrap justify-center items-center gap-2 sm:gap-4 select-none py-2 border-b border-red-600">
        <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider">
          <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
          Preço Promocional Exclusivo para Hoje!
        </span>
        <span className="hidden md:inline font-sans opacity-70">|</span>
        <span className="font-semibold flex items-center gap-1">
          <Clock className="w-3.5 h-3.5 text-red-500" />
          Este desconto de 60% expira em: <strong className="bg-red-600 px-1.5 py-0.5 rounded text-white">{formatTime(time)}</strong>
        </span>
        <button 
          onClick={handlePurchase}
          className="bg-red-600 text-white hover:bg-red-700 font-extrabold px-3 py-0.5 rounded-full text-[10px] uppercase tracking-wide shadow-sm transition active:scale-95 ml-2 cursor-pointer text-center"
        >
          Aproveitar R$ 9,97
        </button>
      </div>

      {/* 2. HEADER */}
      <header className="bg-red-600 px-4 sm:px-8 py-3.5 flex justify-between items-center text-white shadow-lg relative z-30">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-3 font-black text-xl sm:text-2xl tracking-tighter cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
            <div className="bg-white text-red-600 w-8 h-8 rounded-full flex items-center justify-center shadow-md">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                <path d="M11,15H13V12H16V10H13V7H11V10H8V12H11V15M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z" />
              </svg>
            </div> 
            <span className="font-sans font-black tracking-tight flex items-center gap-1">
              SOS PET
              <span className="bg-black text-white text-[9px] font-mono font-black px-1.5 py-0.5 rounded tracking-normal">PRIMEIROS SOCORROS</span>
            </span>
          </div>

          <nav className="hidden lg:flex items-center gap-6 text-xs text-white/90 font-bold uppercase tracking-wider font-sans">
            <a href="#dangers" className="hover:text-white transition">O Perigo</a>
            <a href="#simulator" className="hover:text-white transition">Simulador de Resgate</a>
            <a href="#modules" className="hover:text-white transition">O Que Vou Aprender</a>
            <a href="#testimonials" className="hover:text-white transition">Depoimentos</a>
            <a href="#faq" className="hover:text-white transition">Dúvidas</a>
          </nav>

          <div className="flex items-center gap-4">
            <span className="hidden md:inline text-xs font-bold uppercase tracking-widest text-white/80">Acesso Vitalício</span>
            <button
              id="header-cta-btn"
              onClick={handlePurchase}
              className="bg-black hover:bg-neutral-900 text-white font-black text-[10px] sm:text-xs px-2.5 py-1.5 sm:px-4 sm:py-2 rounded-lg transition active:scale-95 uppercase tracking-wider flex items-center gap-1 sm:gap-1.5 shadow shrink-0 whitespace-nowrap"
            >
              <span>Aproveitar R$ 9,97</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 3. HERO SECTION (SÉRGIO / SEU CACHORRO ENGASGOU? ENGANO OU AMOR) */}
      <section className="relative overflow-hidden bg-slate-50 border-b border-slate-200 py-12 sm:py-20">
        <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80">
          <div className="relative left-[calc(50%-11rem)] aspect-1155/678 w-[36rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-red-100 to-rose-300 opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72rem]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column Content */}
            <div className="lg:col-span-12 xl:col-span-7 space-y-6 text-left">
              
              {/* Emergency Alert Tag */}
              <div className="text-red-650 font-black uppercase tracking-widest text-xs sm:text-sm mb-2 flex items-center gap-1.5 font-mono">
                <ShieldAlert className="w-4 h-4 text-red-600 animate-pulse" />
                Guia de Emergência de Alta Relevância Veterinária para Tutores
              </div>

              {/* Main Headline */}
              <h1 className="font-sans font-black text-3xl sm:text-4xl lg:text-5xl text-slate-900 tracking-tight leading-none">
                Você saberia agir nos <span className="text-red-650 underline decoration-red-600 decoration-3 underline-offset-4">primeiros minutos</span> para salvar o seu cachorro antes de chegar ao veterinário?
              </h1>

              {/* Urgency Subhead */}
              <p className="font-sans text-base sm:text-lg lg:text-xl text-slate-600 leading-relaxed font-normal max-w-2xl">
                Seu cão engasgou com um osso? Comeu algo tóxico? Sabia que tentar enfiar o dedo às cegas pode matá-lo por asfixia? <strong className="text-slate-900">Não espere a hora do desespero</strong> bater para saber como agir e proteger quem você ama.
              </p>

              {/* Quick checks */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-start gap-2 text-xs text-slate-700">
                  <span className="p-0.5 bg-red-100 text-red-750 rounded-full mt-0.5 h-4 w-4 flex items-center justify-center font-black">✓</span>
                  <span><strong>8 Módulos Práticos</strong> de Resgate Imediato.</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-slate-700">
                  <span className="p-0.5 bg-red-100 text-red-750 rounded-full mt-0.5 h-4 w-4 flex items-center justify-center font-black">✓</span>
                  <span>Garantia de <strong>Risco Zero por 7 Dias</strong> Total.</span>
                </div>
              </div>

              {/* Hero Call Actions */}
              <div className="flex flex-col sm:flex-row items-center gap-4 pt-4">
                <button
                  id="hero-buy-btn"
                  onClick={handlePurchase}
                  className="w-full sm:w-auto text-center bg-red-600 hover:bg-red-700 text-white font-bold text-base px-10 py-5 rounded-xl shadow-xl shadow-red-200 uppercase tracking-wide transition transform hover:-translate-y-0.5 active:scale-98 font-black"
                >
                  <span>Garantir Segurança do Meu Pet Agora por R$ 9,97</span>
                </button>
                
                <a 
                  href="#simulator"
                  className="w-full sm:w-auto text-center text-slate-600 hover:text-slate-900 border border-slate-200 bg-white hover:bg-slate-100 font-bold text-xs py-5 px-6 rounded-xl transition shadow-sm flex items-center justify-center gap-2"
                >
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M10,16.5V7L16,12L10,16.5Z" />
                    </svg>
                  </div>
                  <span>Ver Simulador Demo</span>
                </a>
              </div>
              
              {/* Micro Trust metrics */}
              <div className="flex items-center gap-4 border-t border-zinc-200/80 pt-5 text-zinc-400 font-mono text-[10px] uppercase font-bold">
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-600" />
                  Compra Segura Auditada
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-rose-500" />
                  RECOMENDADO POR VETERINÁRIOS
                </span>
              </div>

            </div>

            {/* Right Column (Awesome CSS E-Book Mockup and Peek inside trigger) */}
            <div className="lg:col-span-5 flex justify-center py-6">
              <BookMockup />
            </div>

          </div>
        </div>
      </section>

       {/* 4. STATISTICS & THREAT RADAR (APELO AO MEDO COM AMOR) */}
      <section className="py-16 bg-white border-b border-slate-200" id="dangers">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs text-red-600 font-bold uppercase tracking-widest bg-red-50 px-3.5 py-1.5 rounded-full border border-red-200">
              🚨 Mapeamento de Risco Doméstico
            </span>
            <h2 className="font-sans font-black text-3xl sm:text-4xl text-slate-900 tracking-tight leading-none mt-4">
              Os Riscos Silenciosos Escondidos na Sua Casa Agora
            </h2>
            <p className="text-sm sm:text-base text-slate-600 font-normal leading-relaxed">
              Fatos alarmantes provam que o perigo mora do outro lado da sala. Em uma emergência médica pet, cada segundo perdido reduz a chance de sobrevivência em 15%.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Threat Card 1 */}
            <div className="border-l-4 border-red-500 bg-red-50/75 p-6 sm:p-8 rounded-r-2xl space-y-4 shadow-sm hover:shadow-md transition duration-200 text-left">
              <div className="w-10 h-10 rounded-xl bg-white border border-red-200 flex items-center justify-center shadow-sm">
                💀
              </div>
              <h4 className="font-sans font-black text-lg text-slate-900 uppercase tracking-tight">1. Engasgamento</h4>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                Ossos de carne cozidos ou fragmentos plásticos cravam nas amígdalas do pet. Se você tentar enfiar os dedos, vai empurrar o objeto para os brônquios. A asfixia total causa danos cerebrais graves em menos de 4 minutos.
              </p>
              <div className="font-mono text-[10px] text-red-700 font-bold bg-white border border-red-100 px-2 py-1 rounded w-max shadow-2xs">
                GRAVIDADE: CRÍTICA • 0-5 MINUTOS NO TOTAL
              </div>
            </div>

            {/* Threat Card 2 */}
            <div className="border-l-4 border-orange-500 bg-orange-50/75 p-6 sm:p-8 rounded-r-2xl space-y-4 shadow-sm hover:shadow-md transition duration-200 text-left">
              <div className="w-10 h-10 rounded-xl bg-white border border-orange-200 flex items-center justify-center shadow-sm">
                🍫
              </div>
              <h4 className="font-sans font-black text-lg text-slate-900 uppercase tracking-tight">2. Intoxicação</h4>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                Chocolate, alho, cebola, uvas roxas e produtos de limpeza. Muitas vezes os sintomas só aparecem 6 horas após a deglutição, quando o fígado e rins estão em necrose. Saber como administrar os primeiros socorros economiza tempo precioso.
              </p>
              <div className="font-mono text-[10px] text-orange-700 font-bold bg-white border border-orange-100 px-2 py-1 rounded w-max shadow-2xs">
                GRAVIDADE: ALTA • REAÇÃO EXIGIDA EM 30 MIN
              </div>
            </div>

            {/* Threat Card 3 */}
            <div className="border-l-4 border-purple-500 bg-purple-50/75 p-6 sm:p-8 rounded-r-2xl space-y-4 shadow-sm hover:shadow-md transition duration-200 text-left">
              <div className="w-10 h-10 rounded-xl bg-white border border-purple-200 flex items-center justify-center shadow-sm">
                ☀️
              </div>
              <h4 className="font-sans font-black text-lg text-slate-900 uppercase tracking-tight">3. Insolação</h4>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                Erros em insolação ou choques térmicos matam milhares de bichos no verão. Dar banho gelado abrupto pode paralisar as artérias e matar o cão instantaneamente de parada cardiorrespiratória reflexiva.
              </p>
              <div className="font-mono text-[10px] text-purple-700 font-bold bg-white border border-purple-100 px-2 py-1 rounded w-max shadow-2xs">
                GRAVIDADE: INSTANTÂNEA • REAÇÃO EM 10 MIN
              </div>
            </div>

          </div>

          {/* Social Proof Quote block */}
          <div className="mt-12 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row justify-between items-center gap-6 text-left border border-slate-800 shadow-xl">
            <div className="space-y-2">
              <h4 className="font-sans font-black text-lg sm:text-xl tracking-tight leading-snug">
                "Veterinários não podem evitar acidentes domésticos, mas você pode garantir que seu pet chegue de pé ao consultório clínico."
              </h4>
              <p className="text-xs text-slate-400 font-normal">
                Estatística clínica: 75% dos pets que falecem no trajeto de atropelamento seriam salvos com contenção e estancamento de carótida imediatos feitos pelo tutor.
              </p>
            </div>
            
            <button
              onClick={handlePurchase}
              className="bg-red-650 hover:bg-red-700 text-white font-black py-4 px-8 rounded-xl text-xs flex items-center gap-1 shrink-0 shadow-md shadow-red-900/40 select-none uppercase tracking-wider transition cursor-pointer text-center"
            >
              <span>Prevenir Agora por R$ 9,97</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE CRISIS SIMULATOR (DEDICATED SECTION) */}
      <section className="py-16 sm:py-20 bg-slate-950 text-slate-100" id="simulator">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-[10px] text-red-500 font-mono font-bold uppercase tracking-widest bg-red-500/10 px-3.5 py-1 rounded-full border border-red-500/20">
              🛠️ Ferramenta Interativa Grátis para Você Testar
            </span>
            <h2 className="font-sans font-extrabold text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight leading-none">
              O Teste de Sobrevivência de 1 Minuto
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 font-normal max-w-xl mx-auto leading-relaxed">
              Você saberia o que fazer nos primeiros segundos ou tomaria uma conduta baseada em crenças antigas que colocam a vida do seu bicho em risco fatal? Faça o teste!
            </p>
          </div>

          <CrisisSimulator onBuyClick={handlePurchase} />

        </div>
      </section>

      {/* 6. MODULES CURRICULUM ACCORDION (O QUE O PRODUTO ENTREGA) */}
      <section className="py-16 sm:py-20 bg-white" id="modules">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
            <h2 className="font-sans font-black text-3xl sm:text-4xl text-slate-900 tracking-tight leading-none mt-4">
              Os 8 Módulos de Suporte Básico de Vida Veterinário
            </h2>
            <p className="text-sm text-slate-600 font-normal leading-relaxed max-w-xl mx-auto">
              Cada linha foi redigida para ser aberta em situações extremas. Sem blá-blá-blá teórico de faculdade: apenas ação cirúrgica direta em minutos.
            </p>
          </div>

          <ModuleAccordion />

        </div>
      </section>

      {/* 9. TESTIMONIALS SECTION */}
      <section className="py-16 sm:py-20 bg-slate-50 border-t border-b border-slate-200" id="testimonials">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs text-red-650 font-bold uppercase tracking-widest bg-red-50 px-3.5 py-1.5 rounded-full border border-red-200 font-mono">
              💬 Vozes de Guardiões e Tutores Reais
            </span>
            <h2 className="font-sans font-black text-3xl sm:text-4xl text-slate-900 tracking-tight leading-none mt-4 font-black">
              Eles Agiram Rápido e Salvaram Seus Amigos
            </h2>
            <p className="text-sm text-slate-600 font-normal leading-relaxed max-w-lg mx-auto">
              Veja as histórias inspiradoras de tutores de amor que evitaram erros trágicos e salvaram de engasgamento e envenenamento usando o SOS Pet.
            </p>
          </div>

          <Testimonials />

        </div>
      </section>

      {/* 10. FAQ SECTION */}
      <section className="py-16 sm:py-24 bg-slate-950 text-white" id="faq">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs text-red-400 font-bold uppercase tracking-widest bg-slate-900 px-3.5 py-1.5 rounded-full border border-slate-800 font-mono">
              💬 Dúvidas Frequentes Respondidas
            </span>
            <h2 className="font-sans font-black text-3xl sm:text-4xl text-white tracking-tight leading-none mt-4 font-black">
              Perguntas Frequentes (FAQ) dos Tutores
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 font-normal leading-relaxed max-w-md mx-auto">
              Veja abaixo as respostas das perguntas mais comuns recebidas por nosso suporte veterinário para sua total segurança.
            </p>
          </div>

          <FAQSection />

        </div>
      </section>

      {/* 11. FOOTER */}
      <footer className="bg-slate-900 text-white border-t border-slate-800 py-12 text-center text-xs font-sans font-normal select-none">
        <div className="max-w-4xl mx-auto px-4 space-y-6">
          <div className="flex items-center justify-center gap-2">
            <span className="text-red-500 font-bold font-sans text-xs uppercase tracking-wider">🐾 SOS PET - GUIA DE EMERGÊNCIA</span>
          </div>
          
          <p className="text-slate-400 max-w-2xl mx-auto leading-relaxed text-[11px]">
            © 2026 SOS Pet Guia de Emergências para Tutores. Todos os direitos reservados.<br />
            As informações servem de guia para suporte de emergências domésticas preventivas e não substituem o papel de um hospital veterinário especializado em triagens de urgência.
          </p>

          <div className="flex justify-center gap-4 text-[10px] font-mono text-slate-500 uppercase font-semibold">
            <span>Compra Simulada</span>
            <span>•</span>
            <span>Estabilidade de Redução de Risco</span>
            <span>•</span>
            <span>Acompanhamento Vet Mandatório</span>
          </div>
        </div>
      </footer>

      {/* 12. CHECKOUT DIALOG POPUP */}
      <CheckoutModal 
        isOpen={isCheckoutOpen} 
        onClose={() => setIsCheckoutOpen(false)} 
        basePrice={PROMO_PRICE} 
      />

    </div>
  );
}
