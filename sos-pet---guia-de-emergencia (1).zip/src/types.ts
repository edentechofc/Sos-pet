/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ModuleInfo {
  id: number;
  number: string;
  title: string;
  shortDesc: string;
  duration?: string;
  details: string[];
  icon: string; // lucide icon identifier
}

export interface QuizQuestion {
  id: number;
  scenario: string;
  petType: 'dog' | 'cat' | 'both';
  difficulty: 'fácil' | 'médio' | 'perigoso';
  question: string;
  options: {
    id: string;
    text: string;
    isCorrect: boolean;
    explanation: string;
  }[];
}

export interface Testimonial {
  id: number;
  name: string;
  petName: string;
  petBreed: string;
  avatarUrl: string;
  rating: number;
  text: string;
  tag: string; // e.g., 'História Real', 'Prevenção'
}

export interface FAQItem {
  id: number;
  question: string;
  answer: string;
}
