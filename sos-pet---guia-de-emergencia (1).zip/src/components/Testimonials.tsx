/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Star, ShieldCheck, Heart } from 'lucide-react';
import { Testimonial } from '../types';

const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: 1,
    name: "Mariana Souza",
    petName: "Bob",
    petBreed: "Golden Retriever, 2 Anos",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=120&h=120",
    rating: 5,
    tag: "🚨 História de Resgate",
    text: "O Bob engasgou com um pedaço duro de brinquedo no quintal. Eu entrei em desespero total e ia cometer o erro de enfiar o dedo na garganta dele. Lembrei das instruções de compressão rápida do guia SOS Pet que eu tinha no celular. Fiz a manobra abdominal 3 vezes e ele cuspiu o plástico! Se eu tivesse esperado 15 minutos de trânsito até o vet, ele não estaria mais aqui hoje."
  },
  {
    id: 2,
    name: "Dr. Roberto Mendes",
    petName: "Clínico Veterinário",
    petBreed: "CRMV-SP 4921",
    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=120&h=120",
    rating: 5,
    tag: "🩺 Recomendação Profissional",
    text: "Muitos óbitos em clínicas acontecem não porque o veterinário erra, mas porque o bicho já chega sem oxigenação cerebral ou com hemorragia irreversível. Os primeiros minutos mudam tudo. Esse guia é extremamente didático e correto do ponto de vista médico. Todo tutor deveria ler para saber como estancar sangramentos e transportar o pet de forma correta e sem agravar traumas."
  },
  {
    id: 3,
    name: "Felipe Castanhari",
    petName: "Pipoca",
    petBreed: "Vira-lata (SDR), 5 meses",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120&h=120",
    rating: 5,
    tag: "🍃 Prevenção de Intoxicação",
    text: "Nossa filhotinha Pipoca comeu um pedaço gigante de cebola cozida na cozinha sem a gente ver. Eu não fazia ideia de que cebola causava anemia tão violenta e rápida que podia matar cães! Fui correndo olhar no módulo de envenenamento as quantidades de alerta e o que fazer. Liguei pro veterinário já sabendo passar a triagem correta e ela foi salva a tempo."
  },
  {
    id: 4,
    name: "Juliana Duarte",
    petName: "Mel",
    petBreed: "Shih Tzu, 4 Anos",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=120&h=120",
    rating: 5,
    tag: "☀️ Alerta de Verão",
    text: "No fim de ano fomos para a praia e a Mel começou a ter insolação extrema. Ela estava com a boca roxa e totalmente zonza na areia. Uma amiga ia jogar água gelada nela, mas eu gritei que não podia de jeito nenhum por causa do risco de choque circulatório fatal que li no guia. Molhamos a barriga aos poucos na sombra com água natural e fomos pro carro com ventilador. Salvamos a Mel de um erro horroroso por puro amor."
  }
];

export default function Testimonials() {
  return (
    <div className="w-full" id="testimonials">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {TESTIMONIALS_DATA.map((t) => (
          <div 
            key={t.id}
            className="bg-white border border-zinc-200/80 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col justify-between hover:border-zinc-300 transition-all duration-200"
          >
            <div className="space-y-4">
              {/* Rating and Tag Row */}
              <div className="flex items-center justify-between">
                <div className="flex text-amber-500 gap-0.5">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-red-650 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                  {t.tag}
                </span>
              </div>

              {/* Message text */}
              <p className="text-xs sm:text-sm text-zinc-650 leading-relaxed font-normal">
                "{t.text}"
              </p>
            </div>

            {/* Profile Avatar info */}
            <div className="flex items-center gap-3 border-t border-zinc-100 pt-4 mt-5">
              <img 
                src={t.avatarUrl} 
                alt={t.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover border border-zinc-200"
              />
              <div className="leading-tight">
                <h5 className="font-sans font-extrabold text-xs text-zinc-900 flex items-center gap-1">
                  {t.name}
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                </h5>
                <span className="text-[10px] text-zinc-400 font-mono">
                  Guardião de {t.petName} <span className="text-zinc-300">•</span> {t.petBreed}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
