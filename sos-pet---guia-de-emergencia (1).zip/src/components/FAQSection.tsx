/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle, AlertTriangle } from 'lucide-react';
import { FAQItem } from '../types';

const FAQ_ITEMS: FAQItem[] = [
  {
    id: 1,
    question: "Eu não sou veterinário ou profissional. É seguro eu realizar essas manobras?",
    answer: "Absolutamente sim! O guia não ensina técnicas cirúrgicas ou procedimentos invasivos. Ele ensina Suporte Básico de Vida (SBV) — ações imediatas de primeiros socorros para estabilizar seu animal nos primeiros minutos cruciais e mantê-lo vivo até chegar ao pronto-socorro. É exatamente igual aos primeiros socorros humanos."
  },
  {
    id: 2,
    question: "O guia ensina a dar medicamentos por conta própria para meu bicho?",
    answer: "Não! E alertamos veementemente contra isso. A automedicação do bicho de estimação é uma das maiores causas de intoxicação grave em clínicas. Explicamos apenas como e quando usar itens de adsorção como o Carvão Ativado Vegetal para neutralizar venenos imediatos sob indicação, desmistificando o perigo de dar remédios humanos como Ibuprofeno de forma cega."
  },
  {
    id: 3,
    question: "Como eu recebo o material? Vou receber em casa pelo correio?",
    answer: "O SOS Pet é um infoproduto 100% digital. Você recebe o acesso ao link para download de todos os manuais no formato digital PDF imediatamente no seu e-mail após a confirmação. Isso é ideal porque você pode ter o arquivo salvo no celular, tablet e computador para acesso rápido em qualquer lugar, sem perigo de extraviar."
  },
  {
    id: 4,
    question: "Eu tenho gatos em casa. O guia serve para mim também?",
    answer: "Sim! Embora vários módulos (como a manobra de Heimlich, controle de choque térmico e hemorragias) apliquem-se igualmente a quase todos os pequenos mamíferos peludos, o manual dá foco detalhado nas diferenças fisiológicas importantes para cães. Ao garantir o guia hoje, você também pode selecionar o upgrade opcional SOS Felinos de gatos no checkout com super desconto para sua maior tranquilidade!"
  },
  {
    id: 5,
    question: "E se eu ler as técnicas e achar que não servem para o meu caso, posso pedir reembolso?",
    answer: "Com certeza. Nós temos orgulho do valor prático deste manual de sobrevivência. Se você adquiri-lo e, por qualquer motivo, achar que o conhecimento contido nele não é suficiente para te preparar ou não te sentir satisfeito, basta enviar um e-mail em até 7 dias após a compra simulada ou real e devolvemos 100% do seu dinheiro, sem burocracias ou perguntas."
  }
];

export default function FAQSection() {
  const [openId, setOpenId] = useState<number | null>(1);

  const toggleFAQ = (id: number) => {
    setOpenId(prev => (prev === id ? null : id));
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-3.5" id="faq">
      {FAQ_ITEMS.map((item) => {
        const isOpen = openId === item.id;

        return (
          <div 
            key={item.id}
            className={`border rounded-xl md:rounded-2xl overflow-hidden transition-all duration-300 ${isOpen ? 'bg-slate-900/65 border-slate-700 shadow-lg' : 'bg-slate-900/10 border-slate-800 hover:bg-slate-900/35'}`}
          >
            {/* Question Trigger */}
            <button
              id={`faq-trigger-${item.id}`}
              onClick={() => toggleFAQ(item.id)}
              className="w-full flex items-center justify-between p-5 text-left gap-4"
            >
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-lg shrink-0 ${isOpen ? 'bg-red-500/20 text-red-400 border border-red-500/15' : 'bg-slate-800/40 text-slate-500'}`}>
                  <HelpCircle className="w-4 h-4" />
                </div>
                <h4 className="font-sans font-extrabold text-sm sm:text-base text-zinc-100 tracking-tight leading-snug">
                  {item.question}
                </h4>
              </div>

              <div className={`p-1 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-180 text-white' : ''}`}>
                <ChevronDown className="w-4.5 h-4.5" />
              </div>
            </button>

            {/* Answer body */}
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="px-5 pb-5 pt-1 border-t border-slate-800/60 bg-slate-950/20">
                    <p className="text-xs sm:text-sm text-slate-300 font-normal leading-relaxed">
                      {item.answer}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}

      {/* Advisory Banner */}
      <div className="bg-amber-950/10 border border-amber-500/25 rounded-2xl p-4 flex gap-3 text-left mt-8">
        <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <p className="text-[11px] sm:text-xs text-amber-200/80 leading-relaxed font-normal">
          <strong>Aviso Clínico Responsável:</strong> Este guia digital é focado em suporte básico paliativo de emergência para manter a vida até a entrega segura sob os cuidados médicos cabíveis. Nenhuma técnica contida substitui ou anula o diagnóstico obrigatório e tratamento clínico de um profissional de medicina veterinária registrado.
        </p>
      </div>
    </div>
  );
}
