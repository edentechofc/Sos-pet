/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  ShieldAlert, 
  Award, 
  RotateCcw, 
  X, 
  Check, 
  HelpCircle, 
  Activity, 
  ArrowRight, 
  BrainCircuit,
  Smile,
  AlertTriangle
} from 'lucide-react';
import { QuizQuestion } from '../types';

const SIMULATION_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    scenario: "🚨 SEU CÃO COMEÇOU A ENGASGAR EM CASA COM UM OSSO DE FRANGO!",
    petType: 'dog',
    difficulty: 'perigoso',
    question: "Ele está desesperado, tentando tossir, tossindo sem ar e as gengivas estão começando a ficar roxas. O que você faz nos primeiros 30 segundos?",
    options: [
      {
        id: 'A',
        text: "Enfio imediatamente os dedos profundamente na garganta dele para puxar o osso.",
        isCorrect: false,
        explanation: "❌ ERRO COMUM & CRÍTICO: Empurrar os dedos às cegas na garganta na maioria das vezes empurra o objeto ainda mais para o fundo, obstruindo totalmente as vias aéreas. Além disso, pelo pânico, o cão pode morder com extrema força involuntariamente."
      },
      {
        id: 'B',
        text: "Mantenho a calma, posiciono o cão com a cabeça para baixo se pequeno, ou aplico a manobra de Heimlich abraçando-o por trás e pressionando de forma rápida abaixo das costelas para cima.",
        isCorrect: true,
        explanation: "✅ RESPOSTA CORRETA! A Manobra de Heimlich canina cria uma pressão de ar expulsiva de baixo para cima nos pulmões que ejeta o objeto preso com segurança nas vias aéreas. Saber exatamente onde e como apertar salva vidas em segundos!"
      },
      {
        id: 'C',
        text: "Sacudo ele pelas patas traseiras de cabeça para baixo vigorosamente até o osso cair.",
        isCorrect: false,
        explanation: "❌ ERRO GRAVE: Para cães de médio e grande porte, isso pode causar luxação em juntas e até agravar o trauma respiratório. Sacudir violentamente sem a pressão abdominal correta raramente expele ossos cravados nas amígdalas."
      }
    ]
  },
  {
    id: 2,
    scenario: "🍫 VOCÊ CHEGA NA SALA E SEU PET COMEU UMA BARRA INTEIRA DE CHOCOLATE MEIO AMARGO!",
    petType: 'both',
    difficulty: 'médio',
    question: "Chocolate meio amargo é extremamente tóxico para pets devido à Teobromina. O que fazer de imediato?",
    options: [
      {
        id: 'A',
        text: "Espero algumas horas para ver se ele vai vomitar ou ter diarreia de forma natural.",
        isCorrect: false,
        explanation: "❌ INAÇÃO FATAL: A absorção da Teobromina ocorre em minutos. Quando os sintomas visíveis (batimento cardíaco acelerado, tremores ou convulsão) aparecem, o fígado e rins já estão em colapso agudo. Agir nos primeiros instantes é crucial!"
      },
      {
        id: 'B',
        text: "Forço o cão a beber vinagre puro ou água sanitária diluída para neutralizar o veneno.",
        isCorrect: false,
        explanation: "❌ EXTRA-VENENO: Vinagre puro ou substâncias corrosivas corroem severamente o esôfago do cão, provocando lesões hemorrágicas irreversíveis secundárias que podem ser piores que a toxina do chocolate."
      },
      {
        id: 'C',
        text: "Comunico o veterinário imediatamente e administro de forma controlada Carvão Ativado Vegetal (se disponível) para sequestrar a toxina no estômago.",
        isCorrect: true,
        explanation: "✅ RESPOSTA CORRETA! O Carvão Ativado é o herói silencioso do kit de emergência em casa: ele funciona como um 'ímã', retendo até 80% das toxinas no estômago antes que cheguem à corrente sanguínea. Isso ganha o tempo valioso para chegar ao veterinário."
      }
    ]
  },
  {
    id: 3,
    scenario: "☀️ DIA DE CALOR EXTREMO (40°C): SEU PET DESABABA NA CAMINHADA DESIDRATADO!",
    petType: 'dog',
    difficulty: 'perigoso',
    question: "Ele está com respiração extremamente rápida, língua azulada e incapaz de levantar. Como abaixar a temperatura corporal dele com segurança?",
    options: [
      {
        id: 'A',
        text: "Jogo água congelada ou coloco ele dentro de uma piscina cheia de gelo de uma vez.",
        isCorrect: false,
        explanation: "❌ CHOQUE TÉRMICO FATAL: O resfriamento ultra abrupto causa vasoconstrição extrema (os vasos se fecham). Isso aprisiona todo o calor interno nos órgãos vitais quentes (cérebro e coração), levando a um colapso cardíaco em segundos!"
      },
      {
        id: 'B',
        text: "Levo para a sombra, molho-o gradualmente com água em temperatura ambiente (virilha, patinhas e axilas) e ligo o ar condicionado ou ventilador.",
        isCorrect: true,
        explanation: "✅ RESPOSTA CORRETA! O resfriamento seguro deve ser gradual. Molhar áreas com grandes vasos sanguíneos periféricos (como axilas, virilhas e patas) com água fresca e usar o vento reduz de forma controlada a temperatura sem gerar colapso hemodinâmico."
      },
      {
        id: 'C',
        text: "Enrolo ele totalmente em uma toalha grossa bem encharcada de água fria do congelador.",
        isCorrect: false,
        explanation: "❌ EFEITO ESTUFA: A toalha encharcada retém a umidade mas rapidamente se aquece com a temperatura corporal alta do cão. Ela age como uma barreira de vapor, piorando severamente a dissipação do calor corporal do peludo."
      }
    ]
  }
];

interface CrisisSimulatorProps {
  onBuyClick?: () => void;
}

export default function CrisisSimulator({ onBuyClick }: CrisisSimulatorProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const currentScenario = SIMULATION_QUESTIONS[currentIndex];

  const handleOptionSelect = (optionId: string) => {
    if (showExplanation) return;
    setSelectedOption(optionId);
    setShowExplanation(true);
    
    const option = currentScenario.options.find(o => o.id === optionId);
    if (option?.isCorrect) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setShowExplanation(false);
    if (currentIndex < SIMULATION_QUESTIONS.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
    }
  };

  const restartQuiz = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScore(0);
    setIsFinished(false);
    setShowExplanation(false);
  };

  const getPercentage = () => Math.round((score / SIMULATION_QUESTIONS.length) * 100);

  const getVerdict = () => {
    const pct = getPercentage();
    if (pct === 100) {
      return {
        title: "🛡️ Tutor Protetor Lendário!",
        desc: "Excelente! Você tem ótimos reflexos e conhecimento. Mas lembre-se: emergência não manda aviso. Manter o Guia SOS Pet por perto garante que você não hesite em outros 50 tipos de gravidade.",
        color: "text-emerald-500 bg-emerald-900/10 border-emerald-500/30",
        celebration: true
      };
    } else if (pct >= 50) {
      return {
        title: "⚠️ Tutor Bem-Sucedido Parcialmente (Risco de Sequela)",
        desc: "Você salvou em uma situação, mas cometeu erros fatais em outras. Na vida real, um único erro de primeiros socorros pode tirar a vida do seu melhor amigo ou causar sequelas incuráveis.",
        color: "text-amber-500 bg-amber-900/10 border-amber-500/30",
        celebration: false
      };
    } else {
      return {
        title: "💔 Alerta Crítico: Seu Pet Estaria em Grave Perigo!",
        desc: "Você errou as manobras mais básicas por agir sob crenças populares erradas. Isso é perfeitamente normal: ninguém nasce sabendo. Mas ter o manual de resgate prático ao lado do seu telefone é urgente e obrigatório para você.",
        color: "text-red-500 bg-red-900/10 border-red-500/30",
        celebration: false
      };
    }
  };

  return (
    <div className="w-full bg-slate-900/40 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur" id="crisis-simulator">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
        <div>
          <span className="text-red-500 font-bold uppercase text-[10px] tracking-widest font-mono flex items-center gap-1.5 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/20">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            Simulador de Crise Interativo
          </span>
          <h3 className="font-sans font-extrabold text-white text-xl md:text-2xl mt-2 tracking-tight">
            Teste de Sobrevivência de 1 Minuto
          </h3>
        </div>
        <div className="font-mono text-xs text-slate-400 self-end md:self-auto">
          Cenário <span className="text-white font-bold">{currentIndex + 1}</span> de <span className="text-slate-500">{SIMULATION_QUESTIONS.length}</span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!isFinished ? (
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            {/* Scenario block card */}
            <div className="bg-red-950/20 border-l-4 border-red-500 p-4 rounded-r-xl">
              <span className="text-[10px] text-red-400 font-mono font-bold tracking-wider uppercase block mb-1">CENÁRIO CRÍTICO</span>
              <p className="font-sans font-bold text-sm sm:text-base text-white leading-relaxed">
                {currentScenario.scenario}
              </p>
            </div>

            {/* Difficult & Question header */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <span className="px-2 py-0.5 bg-zinc-800 text-zinc-300 rounded text-[9px] font-mono uppercase">
                  Dificuldade: {currentScenario.difficulty}
                </span>
                <span className="px-2 py-0.5 bg-zinc-850 text-slate-400 rounded text-[9px] font-mono uppercase">
                  Foco: Primeiros Socorros
                </span>
              </div>
              <h4 className="font-sans font-medium text-sm text-slate-200 leading-relaxed">
                {currentScenario.question}
              </h4>
            </div>

            {/* Options grid */}
            <div className="space-y-3">
              {currentScenario.options.map((option) => {
                const isThisSelected = selectedOption === option.id;
                const isCorrect = option.isCorrect;
                
                let optionStyle = "border-slate-800 text-slate-300 bg-slate-900/40 hover:bg-slate-800/80 hover:border-slate-700";
                
                if (showExplanation) {
                  if (isCorrect) {
                    optionStyle = "border-emerald-500/40 text-emerald-300 bg-emerald-950/20 shadow-[0_0_15px_rgba(16,185,129,0.05)]";
                  } else if (isThisSelected) {
                    optionStyle = "border-red-500/40 text-red-300 bg-red-950/25";
                  } else {
                    optionStyle = "border-slate-900 text-slate-500 bg-slate-950/30 opacity-40 pointer-events-none";
                  }
                }

                return (
                  <button
                    id={`quiz-option-${option.id}`}
                    key={option.id}
                    disabled={showExplanation}
                    onClick={() => handleOptionSelect(option.id)}
                    className={`w-full text-left p-4 rounded-xl border text-xs sm:text-sm font-sans flex items-start gap-3 transition-all duration-200 ${optionStyle}`}
                  >
                    <div className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center shrink-0 border text-[10px] font-mono font-bold
                      ${showExplanation && isCorrect ? 'bg-emerald-500 border-emerald-500 text-slate-950' : ''}
                      ${showExplanation && isThisSelected && !isCorrect ? 'bg-red-500 border-red-500 text-white' : ''}
                      ${!showExplanation ? 'bg-slate-800 border-slate-700 text-slate-300' : ''}
                    `}>
                      {showExplanation && isCorrect ? <Check className="w-3 h-3 stroke-[3]" /> : 
                       showExplanation && isThisSelected && !isCorrect ? <X className="w-3 h-3 stroke-[3]" /> : 
                       option.id}
                    </div>
                    <span className="leading-relaxed font-normal">{option.text}</span>
                  </button>
                );
              })}
            </div>

            {/* Explanation box */}
            {showExplanation && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3.5"
              >
                <div>
                  <h5 className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <BrainCircuit className="w-3.5 h-3.5 text-red-500" />
                    Análise Fisiológica do Erro/Acerto:
                  </h5>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    {currentScenario.options.find(o => o.id === selectedOption)?.explanation || 
                     currentScenario.options.find(o => o.isCorrect)?.explanation}
                  </p>
                </div>
                
                <div className="flex justify-end pt-1">
                  <button
                    id="btn-quiz-next"
                    onClick={handleNext}
                    className="flex items-center gap-1 bg-red-650 hover:bg-red-650 text-white px-5 py-2 rounded-lg text-xs font-bold shadow-md shadow-red-600/10 transition"
                  >
                    <span>{currentIndex === SIMULATION_QUESTIONS.length - 1 ? "Ver Meu Veredito" : "Próximo Caso Emergencial"}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-6 space-y-6 max-w-xl mx-auto"
          >
            {/* Verdict Badge */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-slate-950 border-2 border-slate-800 flex items-center justify-center mb-4">
                <Award className={`w-8 h-8 ${getPercentage() === 100 ? 'text-amber-500 animate-pulse' : 'text-slate-400'}`} />
              </div>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Pontuação de Resgate</span>
              <h4 className="text-3xl font-mono font-extrabold text-white mt-1">
                {getPercentage()}% <span className="text-sm font-sans font-normal text-slate-400">Survival Score</span>
              </h4>
            </div>

            {/* Alert banner and description */}
            <div className={`p-5 rounded-2xl border text-left space-y-2 ${getVerdict().color}`}>
              <h5 className="font-sans font-bold text-sm sm:text-base">{getVerdict().title}</h5>
              <p className="text-xs leading-relaxed text-slate-300 font-normal">
                {getVerdict().desc}
              </p>
            </div>

            {/* Conversion Bridge */}
            <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 text-center space-y-3">
              <p className="text-[11px] sm:text-xs text-slate-300">
                ⚠️ <span className="text-red-400 font-bold">Lembre-se:</span> em momentos de desespero, o cérebro congela. Não tente adivinhar ou lembrar do que leu de graça em redes sociais. Você precisa de um guia simples estruturado no celular para abrir e olhar na hora!
              </p>
            </div>

            {/* Direct Link Action */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                id="btn-restart-quiz"
                onClick={restartQuiz}
                className="flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-xs text-slate-300 bg-slate-800 hover:bg-slate-705 border border-slate-700 transition w-full sm:w-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Tentar Novamente</span>
              </button>
              
              <button
                onClick={onBuyClick}
                className="flex items-center justify-center gap-1.5 py-2.5 px-6 rounded-xl text-xs font-extrabold text-white bg-gradient-to-r from-red-600 to-rose-600 hover:opacity-95 shadow-lg shadow-red-600/20 transition-all transform hover:-translate-y-0.5 w-full sm:w-auto cursor-pointer"
              >
                <span>Garantir Guia SOS Pet por R$ 9,97</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
