/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Sparkles, 
  Flame, 
  Activity, 
  Lock, 
  ChevronRight, 
  ChevronLeft, 
  X,
  Stethoscope,
  Heart,
  ShieldAlert
} from 'lucide-react';

export default function BookMockup() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);

  const samplePages = [
    {
      title: "Capa do Guia",
      type: "cover",
      content: (
        <div className="w-full h-full bg-slate-950 text-white flex flex-col justify-between p-6 relative overflow-hidden select-none">
          {/* Decorative Emergency Strips */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-red-600/10 rounded-full blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-red-600/10 rounded-full blur-2xl" />
          
          <div className="flex justify-between items-center z-10">
            <span className="text-[10px] uppercase tracking-widest text-red-500 font-mono font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              Edição Oficial 2026
            </span>
            <span className="text-[10px] uppercase font-mono text-zinc-400"></span>
          </div>

          <div className="my-auto text-center z-10 flex flex-col items-center">
            <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-600/40 mb-4 scale-105">
              <ShieldAlert className="w-9 h-9 text-white" />
            </div>
            
            <h1 className="font-sans font-extrabold text-3xl tracking-tight leading-none text-white">
              SOS <span className="text-red-500 text-3xl block mt-1">PET</span>
            </h1>
            <p className="text-[11px] uppercase tracking-[0.2em] text-zinc-400 mt-2 font-mono">
              Guia de Emergência
            </p>
            
            <div className="w-12 h-[2px] bg-red-600 my-4" />
            
            <p className="text-xs text-zinc-300 max-w-xs font-medium italic leading-relaxed">
              "O que fazer nos primeiros minutos antes de chegar ao veterinário para salvar o seu cachorro."
            </p>
          </div>

          <div className="min-h-6 z-10" />
        </div>
      )
    },
    {
      title: "Módulo 1: Engasgamento",
      subtitle: "Manobra de Heimlich Segura para Cães",
      type: "content",
      content: (
        <div className="p-5 text-zinc-800 h-full flex flex-col justify-between bg-stone-50">
          <div>
            <div className="flex items-center gap-2 border-b border-zinc-200 pb-2 mb-3">
              <span className="p-1 bg-red-100 text-red-600 rounded text-xs font-bold font-mono">PA-01</span>
              <h3 className="font-sans text-sm font-extrabold text-zinc-900">1. Engasgamento & Manobra</h3>
            </div>
            <p className="text-[11px] text-zinc-600 leading-relaxed mb-3">
              Se o cão comer um objeto duro ou um osso pontiagudo e apresentar língua azulada ou perda de consciência:
            </p>
            
            <div className="bg-red-50 border-l-4 border-red-500 p-2.5 rounded mb-3">
              <h4 className="font-bold text-[11px] text-red-800 flex items-center gap-1 mb-1">
                <Flame className="w-3.5 h-3.5" />
                Ação Instantânea:
              </h4>
              <p className="text-[10px] text-red-900 leading-relaxed font-medium">
                1. Posicione o cão de pé com a cabeça para baixo ou deite-o de lado.<br />
                2. Com as duas mãos fechadas em punho abaixo das costelas (no abdômen), pressione firmemente 5 vezes para dentro e para cima.
              </p>
            </div>
            
            <div className="border border-amber-200 bg-amber-50/50 p-2 rounded text-[10px] text-zinc-700">
              <span className="font-bold text-amber-800 block mb-0.5">⚠️ ERRO CRÍTICO A EVITAR:</span>
              Nunca tente enfiar a mão na garganta do cão caso não consiga ver o objeto claramente. Isso pode empurrá-lo ainda mais para baixo.
            </div>
          </div>
          <p className="text-[9px] text-zinc-400 font-mono text-center border-t border-zinc-100 pt-2">Pág. 12 • SOS Pet Guia</p>
        </div>
      )
    },
    {
      title: "Módulo 2: Intoxicação",
      subtitle: "Lista Negra Alimentar de Alerta Máximo",
      type: "content",
      content: (
        <div className="p-5 text-zinc-800 h-full flex flex-col justify-between bg-stone-50">
          <div>
            <div className="flex items-center gap-2 border-b border-zinc-200 pb-2 mb-3">
              <span className="p-1 bg-amber-100 text-amber-700 rounded text-xs font-bold font-mono">PA-02</span>
              <h3 className="font-sans text-sm font-extrabold text-zinc-900">2. Envenenamento e Toxinas</h3>
            </div>
            <p className="text-[11px] text-zinc-600 leading-relaxed mb-2.5">
              Muitos alimentos comuns em casa são altamente venenosos para o fígado e rins dos cães:
            </p>
            
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="bg-zinc-100 p-2 rounded">
                <span className="font-bold text-[10px] text-zinc-900 block border-b border-zinc-200 pb-0.5 mb-1 text-center">💀 Chocolate</span>
                <p className="text-[9px] text-zinc-600 leading-snug">
                  Contém teobromina. Provoca convulsões, arritmia e morte.
                </p>
              </div>
              <div className="bg-zinc-100 p-2 rounded">
                <span className="font-bold text-[10px] text-zinc-900 block border-b border-zinc-200 pb-0.5 mb-1 text-center">💀 Cebola/Alho</span>
                <p className="text-[9px] text-zinc-600 leading-snug">
                  Destroem os glóbulos vermelhos, causando anemia grave.
                </p>
              </div>
              <div className="bg-zinc-100 p-2 rounded">
                <span className="font-bold text-[10px] text-zinc-900 block border-b border-zinc-200 pb-0.5 mb-1 text-center">💀 Uvas (Vinho)</span>
                <p className="text-[9px] text-zinc-600 leading-snug">
                  Apenas 3 uvas podem causar falência renal silenciosa aguda.
                </p>
              </div>
              <div className="bg-zinc-100 p-2 rounded">
                <span className="font-bold text-[10px] text-zinc-900 block border-b border-zinc-200 pb-0.5 mb-1 text-center">💀 Adoçante (Xilitol)</span>
                <p className="text-[9px] text-zinc-600 leading-snug">
                  Provoca hipoglicemia severa em minutos e falência hepática.
                </p>
              </div>
            </div>

            <div className="bg-emerald-50 text-emerald-900 border border-emerald-200 p-2 rounded text-[10px] leading-relaxed">
              <span className="font-bold text-emerald-800 block mb-0.5">💡 Carvão Ativado Vegetal:</span>
              Tenha sempre no kit. Ele neutraliza até 80% do veneno no estômago se administrado logo após a ingestão.
            </div>
          </div>
          <p className="text-[9px] text-zinc-400 font-mono text-center border-t border-zinc-100 pt-2">Pág. 24 • SOS Pet Guia</p>
        </div>
      )
    },
    {
      title: "Módulo 6: Calor Extremo",
      subtitle: "Insolação & Choque Térmico em Cães",
      type: "content",
      content: (
        <div className="p-5 text-zinc-800 h-full flex flex-col justify-between bg-stone-50">
          <div>
            <div className="flex items-center gap-2 border-b border-zinc-200 pb-2 mb-3">
              <span className="p-1 bg-red-100 text-red-600 rounded text-xs font-bold font-mono">PA-06</span>
              <h3 className="font-sans text-sm font-extrabold text-zinc-900">6. Calor Extremo & Insolação</h3>
            </div>
            
            <p className="text-[11px] text-zinc-600 leading-relaxed mb-3">
              Cães não transpiram como nós (apenas pelas almofadas das patas). Eles superaquecem muito rápido, levando ao edema cerebral e falência múltipla de órgãos.
            </p>

            <div className="bg-red-50 border-l-4 border-red-500 p-2.5 rounded mb-3">
              <span className="font-bold text-[10px] text-red-800 block mb-1">❌ O MAIOR ERRO COMUM (MATAL):</span>
              <p className="text-[9px] text-red-900 leading-relaxed font-semibold">
                NUNCA use água congelada ou dê banho extremamente gelado de uma vez em um cão superaquecido!
              </p>
              <p className="text-[9px] text-zinc-600 leading-relaxed mt-1">
                Isso causa contração extrema dos vasos sanguíneos periféricos (vasoconstrição), retendo ainda mais calor no núcleo do corpo e provocando choque fatal.
              </p>
            </div>

            <div className="bg-blue-50 text-blue-900 border border-blue-100 p-2 rounded text-[10px] leading-relaxed">
              <span className="font-bold text-blue-800 block mb-0.5">✅ Maneira Correta e Segura:</span>
              Molhe o cão com água em temperatura ambiente (fresca), molhando a barriga, axilas, virilhas e patas. Use um ventilador para acelerar o resfriamento.
            </div>
          </div>
          <p className="text-[9px] text-zinc-400 font-mono text-center border-t border-zinc-100 pt-2">Pág. 47 • SOS Pet Guia</p>
        </div>
      )
    },
    {
      title: "Final do Livro",
      subtitle: "Módulos Restantes Trancados",
      type: "locked",
      content: (
        <div className="w-full h-full bg-zinc-950 text-white flex flex-col justify-between p-6 relative overflow-hidden select-none">
          <div className="absolute inset-0 bg-radial-gradient from-zinc-900 to-black opacity-90" />
          
          <div className="m-auto text-center z-10 flex flex-col items-center max-w-xs">
            <div className="w-12 h-12 bg-zinc-800 border border-zinc-700 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-6 h-6 text-zinc-400" />
            </div>
            <h3 className="font-sans font-bold text-base text-white">Conteúdo Trancado</h3>
            <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
              Adquira o guia completo hoje para liberar todos os 8 módulos práticos, incluindo:
            </p>
            <ul className="text-[10px] text-red-400 font-mono text-left space-y-1 mt-3.5 border-t border-zinc-800 pt-3">
              <li>↳ Convulsão & Epilepsia</li>
              <li>↳ Atropelamento & Imobilização</li>
              <li>↳ Hemorragias & Ataduras</li>
              <li>↳ Protocolo de Crise Completo</li>
              <li>↳ Lista de Kit de Primeiros Socorros</li>
            </ul>
            <div className="mt-5 w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded text-xs flex items-center justify-center gap-1 cursor-pointer transition-colors shadow shadow-red-600/20">
              <span>Liberar Guia Completo</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="text-center z-10 border-t border-zinc-900/60 pt-4">
            <span className="text-[10px] text-zinc-500 font-mono">Garantia Incondicional de 7 Dias</span>
          </div>
        </div>
      )
    }
  ];

  const handleNextPage = () => {
    if (currentPage < samplePages.length - 1) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* 3D Interactive CSS Book Mockup Container */}
      <div className="relative group perspective-[1500px] cursor-pointer mb-6" onClick={() => setIsOpen(true)}>
        <motion.div 
          className="relative w-64 h-96 transition-all duration-700 ease-out preserve-3d"
          style={{ transformStyle: 'preserve-3d' }}
          whileHover={{ rotateY: -22, rotateX: 6, scale: 1.03 }}
        >
          {/* Ebook Pages Back Stack Effect */}
          <div className="absolute inset-0 bg-white border border-zinc-200 rounded-r-lg shadow-md translate-z-[-2px] origin-left scale-[0.99] ltr" />
          <div className="absolute inset-0 bg-white border border-zinc-200 rounded-r-lg shadow-md translate-z-[-4px] origin-left scale-[0.98] ltr" />
          <div className="absolute inset-0 bg-white border border-zinc-200 rounded-r-lg shadow-md translate-z-[-6px] origin-left scale-[0.97] ltr" />
          
          {/* Book Spine Edge (Thickness) */}
          <div 
            className="absolute left-0 top-0 bottom-0 w-[12px] bg-slate-900 origin-left -translate-x-[6px] rotate-y-[-90deg] border-y border-zinc-800"
            style={{ 
              boxShadow: 'inset -2px 0 10px rgba(0,0,0,0.8)' 
            }}
          />

          {/* Book Spine Face Cover Background */}
          <div className="absolute inset-y-0 -left-1 w-3 bg-red-700/80 rounded-l-md blur-[0.5px] pointer-events-none translate-z-[1px]" />

          {/* Ebook Front Cover */}
          <div 
            className="absolute inset-0 rounded-r-lg overflow-hidden border-y border-r border-slate-900"
            style={{ 
              backfaceVisibility: 'hidden',
              transform: 'translateZ(0px)',
              boxShadow: '10px 15px 35px rgba(0,0,0,0.25), 1px 1px 3px rgba(0,0,0,0.1)'
            }}
          >
            {samplePages[0].content}
          </div>
        </motion.div>

        {/* Hover Cue */}
        <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-1.5 text-xs text-rose-500 font-semibold bg-rose-50 px-3 py-1 rounded-full border border-rose-100 shadow-sm transition-opacity group-hover:scale-105">
          <BookOpen className="w-3.5 h-3.5 animate-bounce" />
          <span>Clique para Folhear o Guia</span>
          <Sparkles className="w-3 h-3 ml-0.5 text-amber-500" />
        </div>
      </div>

      {/* Book Interactive Flier Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            {/* Backdrop Dismiss */}
            <div className="absolute inset-0" onClick={() => setIsOpen(false)} />

            {/* Modal Box */}
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative w-full max-w-lg bg-zinc-900 rounded-2xl overflow-hidden shadow-2xl border border-zinc-800 z-10"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-950">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-red-950 text-red-500 border border-red-500/20 rounded-lg">
                    <Stethoscope className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-sans font-extrabold text-sm text-white">Visualização Parcial</h4>
                    <p className="text-[10px] text-zinc-400">Páginas de Demonstração Interativa</p>
                  </div>
                </div>
                <button 
                  id="btn-close-book"
                  onClick={() => setIsOpen(false)}
                  className="p-1 px-2 text-xs text-zinc-400 hover:text-white rounded bg-zinc-800 hover:bg-zinc-700 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Page Area */}
              <div className="w-full bg-zinc-900 flex justify-center py-8 px-4 sm:px-8 relative min-h-[420px]">
                {/* Pages Layout Background paper */}
                <div className="relative w-full max-w-xs h-[380px] bg-white rounded-lg shadow-xl overflow-hidden border border-zinc-800">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currentPage}
                      initial={{ opacity: 0, x: 15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -15 }}
                      transition={{ duration: 0.2 }}
                      className="w-full h-full"
                    >
                      {samplePages[currentPage].content}
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Progress bar info */}
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-[10px] text-zinc-500 font-mono whitespace-nowrap">
                  Página {currentPage + 1} de {samplePages.length}
                </div>
              </div>

              {/* Navigation Controls */}
              <div className="flex items-center justify-between px-5 py-3 border-t border-zinc-800 bg-zinc-950">
                <button
                  id="btn-prev-page"
                  disabled={currentPage === 0}
                  onClick={handlePrevPage}
                  className="flex items-center gap-1 py-1.5 px-3 rounded text-xs text-zinc-300 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 disabled:opacity-30 disabled:pointer-events-none transition"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Anterior</span>
                </button>

                {/* Progress dots */}
                <div className="flex gap-1.5">
                  {samplePages.map((_, idx) => (
                    <div 
                      key={idx} 
                      className={`h-1.5 rounded-full transition-all duration-300 ${idx === currentPage ? 'w-4 bg-red-500' : 'w-1.5 bg-zinc-700'}`}
                    />
                  ))}
                </div>

                {currentPage === samplePages.length - 1 ? (
                  <button
                    id="btn-close-book-peek"
                    onClick={() => setIsOpen(false)}
                    className="flex items-center gap-1 py-1.5 px-4 rounded text-xs text-white bg-gradient-to-r from-red-600 to-rose-600 font-bold hover:opacity-90 shadow-md shadow-red-600/20 transition"
                  >
                    <span>Quero Comprar Agora</span>
                  </button>
                ) : (
                  <button
                    id="btn-next-page"
                    onClick={handleNextPage}
                    className="flex items-center gap-1 py-1.5 px-3 rounded text-xs text-zinc-300 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition"
                  >
                    <span>Próxima</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
