/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronDown, 
  Flame, 
  Skull, 
  AlertCircle, 
  Truck, 
  Droplet, 
  Thermometer, 
  Briefcase, 
  PhoneCall,
  CheckCircle2,
  Lock
} from 'lucide-react';

const MODULES_DATA = [
  {
    id: 1,
    number: "MÓDULO 01",
    title: "Engasgamento & Obstrução Respiratória",
    shortDesc: "O protocolo cirúrgico para salvar o pet de asfixia mecânica iminente antes do desmaio.",
    icon: Flame,
    color: "text-red-500 bg-red-500/10 border-red-500/20",
    details: [
      "O erro fatal que 90% dos tutores cometem ao tentar enfiar os dedos na garganta do pet em pânico.",
      "A manobra silenciosa de pressão combinada que ejeta o corpo estranho em menos de 15 segundos.",
      "Como detectar o sinal biológico oculto de asfixia total antes que ocorra dano cerebral definitivo."
    ]
  },
  {
    id: 2,
    number: "MÓDULO 02",
    title: "Envenenamento, Intoxicação e Produtos Tóxicos",
    shortDesc: "O que fazer quando ele engole produtos químicos, plantas venenosas ou comidas proibidas.",
    icon: Skull,
    color: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    details: [
      "O alimento comum e inofensivo na sua cozinha que causa necrose renal e hepática silenciosa em poucas horas.",
      "A substância natural barata de farmácia que atua como barreira estomacal neutralizando as toxinas antes da corrente de sangue.",
      "O perigo devastador de provocar vômitos às cegas e como isso pode acidificar e destruir o esôfago do animal."
    ]
  },
  {
    id: 3,
    number: "MÓDULO 03",
    title: "Convulsões, Ataques Epiléticos e Desmaios",
    shortDesc: "Como proteger as funções motoras e conter o corpo do pet durante espasmos violentos.",
    icon: AlertCircle,
    color: "text-yellow-500 bg-yellow-500/10 border-yellow-500/20",
    details: [
      "A lenda urbana perigosa de puxar a língua do cão e como essa ação amadora pode custar a vida dele.",
      "O protocolo de fixação de 60 segundos que resguarda o pet contra paradas neurológicas irreversíveis.",
      "Como agir durante o pós-crise (cegueira e desorientação temporária) para evitar mordidas acidentais."
    ]
  },
  {
    id: 4,
    number: "MÓDULO 04",
    title: "Atropelamentos, Traumas Físicos e Quedas",
    shortDesc: "Imobilização corporal imediata e transporte seguro sem agravar fraturas ou hemorragias.",
    icon: Truck,
    color: "text-blue-500 bg-blue-500/10 border-blue-500/20",
    details: [
      "Como projetar e improvisar uma maca perfeitamente plana usando itens que você já tem na sua sala.",
      "A técnica de contenção em dor física extrema: por que até o bicho mais amável do mundo ataca o dono ao sofrer impactos.",
      "O ponto corporal exato onde você jamais deve pressionar para evitar o rompimento de órgãos internos."
    ]
  },
  {
    id: 5,
    number: "MÓDULO 05",
    title: "Hemorragias, Cortes e Sangramentos Diretos",
    shortDesc: "O método de contenção circulatória para estancar perdas severas de sangue em minutos.",
    icon: Droplet,
    color: "text-rose-500 bg-rose-500/10 border-rose-500/20",
    details: [
      "A compressão estanque em vias arteriais que interrompe hemorragias severas a caminho do atendimento.",
      "O erro crônico do garroteamento amador que causa infecções e necrose dos tecidos vitais do membro do pet.",
      "Bandagens compressivas de emergência utilizando faixas elásticas ou tecidos domésticos comuns."
    ]
  },
  {
    id: 6,
    number: "MÓDULO 06",
    title: "Calor Extremo, Insolação e Choque Térmico",
    shortDesc: "Regulação da temperatura corpórea e sinais críticos de falência respiratória por calor.",
    icon: Thermometer,
    color: "text-orange-500 bg-orange-500/10 border-orange-500/20",
    details: [
      "O mito do mergulho em água congelada: por que resfriar o pet abruptamente paralisa as artérias e pode induzir choque.",
      "Os 3 pontos térmicos fisiológicos cruciais do pet para dissipação rápida do calor interno com segurança.",
      "Como detectar a fadiga por calor extremo antes que o sistema biológico entre em falência de múltiplos órgãos."
    ]
  },
  {
    id: 7,
    number: "MÓDULO 07",
    title: "Kit de Emergência Essencial em Casa",
    shortDesc: "Gaveta de suporte preparada com insumos simples de farmácia para poupar custos altos.",
    icon: Briefcase,
    color: "text-emerald-500 bg-emerald-500/10 border-emerald-500/20",
    details: [
      "Os 5 itens de baixíssimo custo médico que substituem dezenas de reais em consultas tardias.",
      "A proporção exata para soluções antissépticas puras de limpeza tecidual em acidentes domésticos.",
      "Como realizar o checklist preventivo da sua gaveta médica sem gastar mais que R$ 30,00 no total."
    ]
  },
  {
    id: 8,
    number: "MÓDULO 08",
    title: "Protocolo de Crise e Contatos Estratégicos",
    shortDesc: "Aceleração do atendimento na triagem clínica para priorizar a vida do animal na recepção.",
    icon: PhoneCall,
    color: "text-purple-500 bg-purple-500/10 border-purple-500/20",
    details: [
      "As 3 perguntas vitais a serem feitas pela chamada à triagem enquanto você faz o transporte rápido do pet.",
      "O método de controle emocional do tutor para impedir que o estresse acelere os batimentos cardíacos do cão ferido.",
      "Como filtrar e registrar hospitais 24 horas confiáveis no seu percurso rotineiro."
    ]
  }
];

const getModuleTheme = (id: number) => {
  switch (id) {
    case 1: return { border: "border-l-4 border-red-500", bg: "bg-red-50" };
    case 2: return { border: "border-l-4 border-orange-500", bg: "bg-orange-50" };
    case 3: return { border: "border-l-4 border-blue-500", bg: "bg-blue-50" };
    case 4: return { border: "border-l-4 border-slate-500", bg: "bg-slate-100" };
    case 5: return { border: "border-l-4 border-red-700", bg: "bg-red-50" };
    case 6: return { border: "border-l-4 border-yellow-500", bg: "bg-yellow-50" };
    case 7: return { border: "border-l-4 border-green-600", bg: "bg-green-50" };
    case 8: return { border: "border-l-4 border-purple-500", bg: "bg-purple-50" };
    default: return { border: "border-l-4 border-red-500", bg: "bg-red-50" };
  }
};

export default function ModuleAccordion() {
  const [expandedId, setExpandedId] = useState<number | null>(1);

  const toggleExpand = (id: number) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-4" id="modules">
      {MODULES_DATA.map((mod) => {
        const isExpanded = expandedId === mod.id;
        const IconComponent = mod.icon;
        const themeClass = getModuleTheme(mod.id);

        return (
          <div 
            key={mod.id}
            className={`border border-y border-r border-slate-200 rounded-r-2xl overflow-hidden transition-all duration-300 shadow-sm ${themeClass.border} ${isExpanded ? 'bg-white border-r border-slate-350 shadow-md' : `${themeClass.bg} hover:brightness-95`}`}
          >
            {/* Header / Trigger */}
            <button
              id={`module-trigger-${mod.id}`}
              onClick={() => toggleExpand(mod.id)}
              className="w-full flex items-start sm:items-center justify-between p-5 text-left gap-4"
            >
              <div className="flex items-start sm:items-center gap-4">
                {/* Module Badge/Icon */}
                <div className={`p-3 rounded-xl border shrink-0 hidden sm:block ${mod.color}`}>
                  <IconComponent className="w-5 h-5" />
                </div>
                
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] sm:text-xs font-sans font-semibold tracking-wider text-zinc-400 uppercase">
                      {mod.number}
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-zinc-300" />
                    <span className="text-[10px] text-zinc-500 font-light">Guia Digital Prático</span>
                  </div>
                  <h4 className="font-sans font-extrabold text-sm sm:text-base text-zinc-900 tracking-tight leading-snug">
                    {mod.title}
                  </h4>
                  <p className="text-xs text-zinc-500 font-normal line-clamp-1 sm:line-clamp-none max-w-xl">
                    {mod.shortDesc}
                  </p>
                </div>
              </div>

              {/* Expansion Indicator */}
              <div className={`p-1.5 rounded-full border border-zinc-200 text-zinc-400 bg-white transition-transform duration-300 mt-1 sm:mt-0 ${isExpanded ? 'rotate-180 text-zinc-950 border-zinc-400' : ''}`}>
                <ChevronDown className="w-4 h-4" />
              </div>
            </button>

            {/* Content Body */}
            <AnimatePresence initial={false}>
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: 'easeInOut' }}
                >
                  <div className="px-5 pb-6 border-t border-zinc-100 bg-zinc-50/40">
                    <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      {mod.details.map((detail, index) => (
                        <div key={index} className="flex items-start gap-2 text-zinc-700 bg-white border border-zinc-100 rounded-xl p-3 shadow-inner">
                          <div className="p-0.5 bg-emerald-100 text-emerald-700 rounded-full mt-0.5 shrink-0">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </div>
                          <span className="text-xs font-medium leading-normal">{detail}</span>
                        </div>
                      ))}
                    </div>

                    {/* Module Status Footer Info */}
                    <div className="mt-5 flex items-center justify-between border-t border-zinc-100 pt-4 text-[10px] text-zinc-400 font-sans font-medium tracking-wider uppercase">
                      <span>✓ Acesso Vitalício</span>
                      <span className="flex items-center gap-1">
                        <Lock className="w-3 h-3 text-red-500" />
                        Suporte Completo Incluído
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
