/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Lock, 
  CreditCard, 
  CheckCircle, 
  Sparkles, 
  Plus, 
  BadgeAlert, 
  TicketPercent, 
  ShieldCheck, 
  QrCode, 
  ArrowRight,
  UserCheck,
  Award
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  basePrice: number;
}

export default function CheckoutModal({ isOpen, onClose, basePrice }: CheckoutModalProps) {
  const [buyerName, setBuyerName] = useState('');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card'>('pix');
  const [addCatBump, setAddCatBump] = useState(false);
  const [addNutritionBump, setAddNutritionBump] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Card Inputs
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  const catBumpPrice = 14.90;
  const nutritionBumpPrice = 12.00;

  const calculateTotal = () => {
    let total = basePrice;
    if (addCatBump) total += catBumpPrice;
    if (addNutritionBump) total += nutritionBumpPrice;
    return parseFloat(total.toFixed(2));
  };

  const handleSimulatePayment = (e: FormEvent) => {
    e.preventDefault();
    if (!buyerName.trim() || !buyerEmail.trim()) return;
    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          {/* Backdrop */}
          <div className="absolute inset-0" onClick={onClose} />

          {/* Dialog Body */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-white rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 z-10 text-zinc-800"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-150 bg-stone-50">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-red-100 text-red-600 rounded-lg">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans font-extrabold text-sm sm:text-base text-zinc-900 leading-tight">Checkout 100% Seguro</h4>
                  <p className="text-[10px] text-zinc-400 font-mono tracking-wider">PREVIEW COMPARTILHADO • AMBIENTE DE TESTE</p>
                </div>
              </div>
              <button
                id="btn-checkout-close"
                onClick={onClose}
                className="p-1.5 text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <AnimatePresence mode="wait">
              {!isSuccess ? (
                <form onSubmit={handleSimulatePayment} className="p-6 space-y-5 max-h-[82vh] overflow-y-auto">
                  
                  {/* Notice Alert */}
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex gap-2.5">
                    <BadgeAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-[10px] sm:text-xs text-amber-800 leading-relaxed">
                      Este é um <strong>ambiente de simulação</strong>. Você não será cobrado em dinheiro real e após confirmar o envio poderá simular o download do manual!
                    </p>
                  </div>

                  {/* Personal info Form */}
                  <div className="space-y-3">
                    <h5 className="text-[11px] font-mono uppercase tracking-wider text-zinc-400">1. Seus Dados de Acesso Seguro</h5>
                    <div className="space-y-2">
                      <input
                        type="text"
                        required
                        placeholder="Nome Completo"
                        value={buyerName}
                        onChange={(e) => setBuyerName(e.target.value)}
                        className="w-full text-xs font-medium p-3 bg-stone-50 border border-zinc-200 rounded-xl focus:ring-1 focus:ring-red-500 focus:outline-none"
                      />
                      <input
                        type="email"
                        required
                        placeholder="E-mail principal (onde receberá o Guia)"
                        value={buyerEmail}
                        onChange={(e) => setBuyerEmail(e.target.value)}
                        className="w-full text-xs font-medium p-3 bg-stone-50 border border-zinc-200 rounded-xl focus:ring-1 focus:ring-red-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Order bumps */}
                  <div className="space-y-3">
                    <h5 className="text-[11px] font-mono uppercase tracking-wider text-zinc-400">2. Ofertas de Upgrade Únicas</h5>
                    <div className="space-y-2">
                      
                      {/* Bump 1 */}
                      <label 
                        id="label-bump-cat"
                        className={`block border rounded-xl p-3 cursor-pointer transition select-none ${addCatBump ? 'bg-red-50/40 border-red-500/40' : 'bg-white border-zinc-200/80 hover:bg-stone-50'}`}
                      >
                        <div className="flex items-start gap-3">
                          <input 
                            type="checkbox"
                            className="mt-1 accent-red-650"
                            checked={addCatBump}
                            onChange={(e) => setAddCatBump(e.target.checked)}
                          />
                          <div className="space-y-0.5">
                            <span className="text-[9px] font-mono font-bold uppercase text-red-600 bg-red-100/60 px-1.5 py-0.5 rounded">Recomendado</span>
                            <h6 className="font-sans font-bold text-xs text-zinc-900 mt-1">Ebook SOS Felinos: Adicionar Guia de Emergência de Gatos?</h6>
                            <p className="text-[10px] text-zinc-500 leading-normal">Se você também tem gatinhos ou quer se prevenir. De R$ 29 por apenas +R$ 14,90.</p>
                          </div>
                        </div>
                      </label>

                      {/* Bump 2 */}
                      <label 
                        id="label-bump-nutrition"
                        className={`block border rounded-xl p-3 cursor-pointer transition select-none ${addNutritionBump ? 'bg-red-50/40 border-red-500/40' : 'bg-white border-zinc-200/80 hover:bg-stone-50'}`}
                      >
                        <div className="flex items-start gap-3">
                          <input 
                            type="checkbox"
                            className="mt-1 accent-red-650"
                            checked={addNutritionBump}
                            onChange={(e) => setAddNutritionBump(e.target.checked)}
                          />
                          <div className="space-y-0.5">
                            <span className="text-[9px] font-mono font-bold uppercase text-emerald-600 bg-emerald-100/60 px-1.5 py-0.5 rounded">Guia Alimentar</span>
                            <h6 className="font-sans font-bold text-xs text-zinc-900 mt-1">Kit Alimentação de Sobrevivência Pet?</h6>
                            <p className="text-[10px] text-zinc-500 leading-normal">O que fazer se ficarem sem ração convencional ou em longos isolamentos. Apenas +R$ 12,00.</p>
                          </div>
                        </div>
                      </label>

                    </div>
                  </div>

                  {/* Payment method selection */}
                  <div className="space-y-3">
                    <h5 className="text-[11px] font-mono uppercase tracking-wider text-zinc-400">3. Método de Pagamento Simulado</h5>
                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        id="btn-method-pix"
                        type="button"
                        onClick={() => setPaymentMethod('pix')}
                        className={`p-3.5 border rounded-xl flex flex-col items-center justify-center gap-1.5 transition ${paymentMethod === 'pix' ? 'bg-emerald-50/60 border-emerald-500 text-emerald-700' : 'bg-white border-zinc-250 text-zinc-500 hover:bg-stone-50'}`}
                      >
                        <QrCode className="w-5 h-5" />
                        <span className="font-sans font-bold text-xs">PIX Instantâneo</span>
                      </button>
                      <button
                        id="btn-method-card"
                        type="button"
                        onClick={() => setPaymentMethod('card')}
                        className={`p-3.5 border rounded-xl flex flex-col items-center justify-center gap-1.5 transition ${paymentMethod === 'card' ? 'bg-red-50/60 border-red-500 text-red-600' : 'bg-white border-zinc-250 text-zinc-500 hover:bg-stone-50'}`}
                      >
                        <CreditCard className="w-5 h-5" />
                        <span className="font-sans font-bold text-xs">Cartão de Crédito</span>
                      </button>
                    </div>

                    {/* Card detailed form */}
                    {paymentMethod === 'card' && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="space-y-2 pt-1"
                      >
                        <input
                          type="text"
                          required
                          placeholder="Número do Cartão (Simulado)"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full text-xs p-2.5 bg-stone-50 border border-zinc-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-500"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            required
                            placeholder="Validade (MM/AA)"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-zinc-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-500"
                          />
                          <input
                            type="text"
                            required
                            placeholder="CVV"
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-zinc-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-500"
                          />
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Summary Pricing */}
                  <div className="bg-stone-50 border border-zinc-150 rounded-2xl p-4 space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-zinc-500 font-sans">SOS Pet Guia Digital:</span>
                      <span className="font-mono text-zinc-700">R$ {basePrice.toFixed(2)}</span>
                    </div>
                    {addCatBump && (
                      <div className="flex justify-between items-center text-xs text-red-650">
                        <span className="font-sans">↳ Add SOS Cat Guide Upgrade:</span>
                        <span className="font-mono">+ R$ {catBumpPrice.toFixed(2)}</span>
                      </div>
                    )}
                    {addNutritionBump && (
                      <div className="flex justify-between items-center text-xs text-emerald-650">
                        <span className="font-sans">↳ Add Survival Food Upgrade:</span>
                        <span className="font-mono">+ R$ {nutritionBumpPrice.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center pt-2 border-t border-zinc-200">
                      <span className="font-sans font-extrabold text-sm text-zinc-900">Total Devido Simulado:</span>
                      <span className="font-mono font-extrabold text-base text-zinc-900">R$ {calculateTotal().toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Action */}
                  <button
                    id="btn-checkout-confirm"
                    type="submit"
                    disabled={isProcessing}
                    className="w-full text-center py-3.5 bg-gradient-to-r from-red-600 to-rose-600 hover:opacity-95 text-white font-extrabold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-red-600/20 active:scale-[0.99] transition"
                  >
                    {isProcessing ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                        Processando Conexão Segura...
                      </span>
                    ) : (
                      <>
                        <span>Finalizar Compra Auditada</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="flex justify-center items-center gap-1.5 text-[9px] text-zinc-400 font-semibold font-mono uppercase text-center">
                    <Lock className="w-3 h-3 text-emerald-600" />
                    <span>Conexão Encriptada AES-256 SSL</span>
                  </div>

                </form>
              ) : (
                /* Success Screen state */
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-8 text-center space-y-6"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 border border-emerald-200 flex items-center justify-center mb-4">
                      <CheckCircle className="w-8 h-8 animate-[scaleIn_0.30s_ease-out]" />
                    </div>
                    <span className="text-[10px] text-emerald-600 font-bold font-mono uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                      Simulação Aprovada com Sucesso!
                    </span>
                    <h4 className="font-sans font-extrabold text-2xl text-zinc-900 mt-3 tracking-tight">
                      Parabéns, {buyerName.split(' ')[0]}!
                    </h4>
                    <p className="text-xs text-zinc-500 mt-2 max-w-sm leading-relaxed">
                      Sua compra simulada foi processada instantaneamente. Em instantes, o link do PDF de demonstração será liberado!
                    </p>
                  </div>

                  {/* Simulated Pix QR Code Area */}
                  {paymentMethod === 'pix' && (
                    <div className="bg-stone-50 border border-zinc-200 p-4 rounded-2xl max-w-xs mx-auto space-y-3.5">
                      <div className="w-32 h-32 bg-zinc-200 border border-zinc-300 mx-auto rounded-lg flex items-center justify-center font-mono text-[10px] p-2 text-zinc-500">
                        {/* Custom visual Mock QR representing complete flow */}
                        <div className="w-full h-full border-4 border-zinc-400 border-double opacity-65 flex flex-col justify-between p-1.5 leading-none">
                          <div className="flex justify-between"><div className="w-4 h-4 bg-zinc-600"/><div className="w-4 h-4 bg-zinc-600"/></div>
                          <span className="text-[8px] font-mono select-none uppercase tracking-wide">COMPLEMENTADO</span>
                          <div className="flex justify-between items-end"><div className="w-4 h-4 bg-zinc-600"/><div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"/></div>
                        </div>
                      </div>
                      <span className="text-[9px] text-zinc-400 font-mono tracking-wider block">PIX DE R$ {calculateTotal().toFixed(2)} CONFIRMADO</span>
                    </div>
                  )}

                  {/* Download Access Sheet */}
                  <div className="bg-red-50/50 border border-red-200 rounded-2xl p-4 text-left space-y-3.5">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-red-100 text-red-600 rounded">
                        <Award className="w-4 h-4" />
                      </div>
                      <span className="font-sans font-extrabold text-xs text-zinc-900">Seu Acesso Completo de Testes:</span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="text-xs text-zinc-600 flex items-center gap-1.5 font-sans">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        AcessoVitalício no E-mail: <strong className="text-zinc-800">{buyerEmail}</strong>
                      </div>
                      <div className="text-xs text-zinc-600 flex items-center gap-1.5 font-sans">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        Guia de Primeiros Socorros: <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold font-mono px-1.5 py-0.2 rounded">LIBERADO</span>
                      </div>
                      {addCatBump && (
                        <div className="text-xs text-zinc-600 flex items-center gap-1.5 font-sans">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                          Guia de Emergência para Gatos: <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold font-mono px-1.5 py-0.2 rounded">LIBERADO</span>
                        </div>
                      )}
                    </div>

                    <button
                      id="btn-simulate-full-dl"
                      onClick={() => {
                        // Trigger simple sample text download
                        const text = `SOS PET: Guia de Emergências para Tutores\nNome do Comprador: ${buyerName}\nEmail: ${buyerEmail}\n\nObrigado por visualizar nossa Demonstração!\nEste manual é um infoproduto simulado.\n\nMais informações no nicho de pets: adote sempre com carinho e faça acompanhamento veterinário periódico!`;
                        const blob = new Blob([text], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `demonstracao_sos_pet_guia.txt`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                      }}
                      className="w-full text-center py-2 bg-zinc-950 hover:bg-zinc-900 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Baixar Amostra de Material</span>
                    </button>
                  </div>

                  {/* Reset action */}
                  <div className="flex justify-center gap-2">
                    <button
                      id="btn-checkout-reset"
                      onClick={() => {
                        setIsSuccess(false);
                        setBuyerName('');
                        setBuyerEmail('');
                        setAddCatBump(false);
                        setAddNutritionBump(false);
                      }}
                      className="text-xs text-zinc-400 hover:text-zinc-600 underline font-medium transition"
                    >
                      Realizar Nova Simulação
                    </button>
                  </div>

                </motion.div>
              )}
            </AnimatePresence>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
